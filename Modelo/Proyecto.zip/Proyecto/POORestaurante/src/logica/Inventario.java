package logica;

public class Inventario {

}
