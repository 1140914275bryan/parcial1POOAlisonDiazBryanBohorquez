package logica;

import java.util.ArrayList;

public class Factura {
	private Date hora;
	private Date fecha;
	private int valorTotal;
	
	private Cajero cajero;
	private ArrayList<FacturaPedido> facturaPedidos;
	
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public int getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(int valorTotal) {
		this.valorTotal = valorTotal;
	}
	public Cajero getCajero() {
		return cajero;
	}
	public void setCajero(Cajero cajero) {
		this.cajero = cajero;
	}
	public ArrayList<FacturaPedido> getFacturaPedidos() {
		return facturaPedidos;
	}
	public void setFacturaProductos(ArrayList<FacturaPedido> facturaPedidos) {
		this.facturaPedidos = facturaPedidos;
	}
	public Factura(Date fecha, Cajero cajero) {
		super();
		this.fecha = fecha;
		this.cajero = cajero;
		this.facturaPedidos = new ArrayList<FacturaPedido>();
	}
	public void calcularTotal() {
		int total = 0;
		for(FacturaPedido facturaPedido : this.facturaPedidos) {
			total += facturaPedido.getPrecio() * facturaPedido.getCantidad();
		}
		this.valorTotal = total;
	}
	public void adicionarPedido(Pedido pedido, int cantidad) {
		FacturaPedido facturaPedido = new FacturaPedido(cantidad, pedido.getPrecioVenta(), pedido);
		this.facturaPedidos.add(facturaPedido);		
	}
}
