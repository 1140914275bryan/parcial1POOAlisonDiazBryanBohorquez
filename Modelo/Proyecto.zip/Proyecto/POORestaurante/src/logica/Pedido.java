package logica;

public class Pedido {
	private int numerodeeleccion;
	private String nombre;
	private int precioVenta;
	private int cantidad;
	public int getnumerodeelccion() {
		return numerodeeleccion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getPrecioVenta() {
		return precioVenta;
	}
	public void setPrecioVenta(int precioVenta) {
		this.precioVenta = precioVenta;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public Pedido(int numerodeeleccion, String nombre, int precioVenta, int cantidad) {
		this.numerodeeleccion = numerodeeleccion;
		this.nombre = nombre;
		this.precioVenta = precioVenta;
		this.cantidad = cantidad;
	}
}
