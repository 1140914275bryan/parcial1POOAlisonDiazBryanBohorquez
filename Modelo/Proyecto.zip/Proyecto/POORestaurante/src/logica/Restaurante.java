package logica;

import java.util.ArrayList;

public class Restaurante {
	private ArrayList<TipoPedido> tipoPedidos;
	private ArrayList<Cajero> cajeros;
	private ArrayList<Factura> facturas;
	
	
	public Restaurante() {
		this.tipoPedidos = new ArrayList<TipoPedido>();
		this.cajeros = new ArrayList<Cajero>();
		this.facturas = new ArrayList<Factura>();
	}

}
